// Copyright (C) 2025 Baracuda
// Pong - A fast-paced multiplayer game for Spixi Mini Apps

// Game constants
const CANVAS_WIDTH = 800;
const CANVAS_HEIGHT = 600;
const PADDLE_WIDTH = 15;
const PADDLE_HEIGHT = 100;
const BALL_SIZE = 12;
const PADDLE_SPEED = 8;
const BALL_SPEED_INITIAL = 6;
const BALL_SPEED_INCREMENT = 0.3;
const MAX_LIVES = 3;
const FRAME_RATE = 60;
const PADDLE_UPDATE_RATE = 16; // Send paddle updates ~60fps

// Game state
let gameState = {
    localPaddle: { y: CANVAS_HEIGHT / 2 - PADDLE_HEIGHT / 2, lives: MAX_LIVES },
    remotePaddle: { y: CANVAS_HEIGHT / 2 - PADDLE_HEIGHT / 2, lives: MAX_LIVES },
    ball: {
        x: CANVAS_WIDTH / 2,
        y: CANVAS_HEIGHT / 2,
        vx: 0,
        vy: 0
    },
    isBallOwner: false, // Who controls the ball (randomly assigned)
    isLeftPlayer: false, // Which side we're on (for rendering)
    gameStarted: false,
    gameEnded: false,
    lastUpdate: 0
};

// Ball interpolation state for smooth sync
let ballTarget = {
    x: CANVAS_WIDTH / 2,
    y: CANVAS_HEIGHT / 2,
    vx: 0,
    vy: 0
};
let ballInterpolationSpeed = 0.5; // Higher = faster catch-up
let lastBallUpdate = Date.now();
const BALL_UPDATE_RATE = 16; // Send every 16ms (60fps) for smooth sync
const SYNC_RATE = 16; // Unified state update rate (60fps)

// Paddle interpolation for smooth remote paddle
let remotePaddleTarget = CANVAS_HEIGHT / 2 - PADDLE_HEIGHT / 2;
const PADDLE_LERP_FACTOR = 0.4;

let canvas, ctx;
let remotePlayerAddress = '';
let sessionId = '';
let playerLastSeen = 0;
let lastDataSent = 0;
let lastSyncTime = 0;
let frameCounter = 0;
let lastSentPaddleY = 0;
let keysPressed = {};
let touchControlActive = null;
let connectionEstablished = false;
let localPlayerReady = false;
let remotePlayerReady = false;
let countdownActive = false;
let countdownValue = 3;
let autoStartTimer = null;
let gameStartTime = 0;

// Network ping interval
let pingInterval = null;
let gameLoopInterval = null;

// Simplified connection handshake
function establishConnection() {
    // Send connection request with our session ID
    const msg = { a: "connect", sid: sessionId };
    SpixiAppSdk.sendNetworkData(JSON.stringify(msg));
    lastDataSent = SpixiTools.getTimestamp();
}

function handleConnectionEstablished() {
    connectionEstablished = true;
    
    // Update connection status
    const statusLabel = document.querySelector('.status-label');
    if (statusLabel) {
        statusLabel.textContent = 'Connected';
    }
    
    // Start regular ping
    if (!pingInterval) {
        pingInterval = setInterval(() => {
            const currentTime = SpixiTools.getTimestamp();
            if (currentTime - lastDataSent >= 2) {
                lastDataSent = currentTime;
                SpixiAppSdk.sendNetworkData(JSON.stringify({ a: "ping" }));
            }
        }, 2000);
    }
    
    // Smooth transition to game screen
    const waitingScreen = document.getElementById('waiting-screen');
    const gameScreen = document.getElementById('game-screen');
    
    waitingScreen.classList.remove('screen-active');
    waitingScreen.classList.add('screen-hidden');
    gameScreen.classList.remove('screen-hidden');
    gameScreen.classList.add('screen-active');
    
    document.getElementById('status-text').textContent = 'CONNECTING...';
    document.getElementById('startBtn').style.display = 'none';
    
    // Auto-start game immediately
    autoStartTimer = setTimeout(() => {
        localPlayerReady = true;
        remotePlayerReady = true;
        startCountdown();
    }, 500);
}

function initGame() {
    canvas = document.getElementById('pongCanvas');
    ctx = canvas.getContext('2d');
    canvas.width = CANVAS_WIDTH;
    canvas.height = CANVAS_HEIGHT;
    
    setupControls();
    
    // Show waiting screen initially with modern classes
    const waitingScreen = document.getElementById('waiting-screen');
    waitingScreen.classList.add('screen-active');
    waitingScreen.classList.remove('screen-hidden');
    
    updateLivesDisplay();
}

function setupControls() {
    // Keyboard controls
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
            keysPressed['up'] = true;
            e.preventDefault();
        }
        if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') {
            keysPressed['down'] = true;
            e.preventDefault();
        }
    });
    
    document.addEventListener('keyup', (e) => {
        if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
            keysPressed['up'] = false;
        }
        if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') {
            keysPressed['down'] = false;
        }
    });
    
    // Touch controls
    const upBtn = document.getElementById('upBtn');
    const downBtn = document.getElementById('downBtn');
    
    upBtn.addEventListener('touchstart', (e) => {
        e.preventDefault();
        touchControlActive = 'up';
    });
    
    upBtn.addEventListener('touchend', (e) => {
        e.preventDefault();
        touchControlActive = null;
    });
    
    downBtn.addEventListener('touchstart', (e) => {
        e.preventDefault();
        touchControlActive = 'down';
    });
    
    downBtn.addEventListener('touchend', (e) => {
        e.preventDefault();
        touchControlActive = null;
    });
    
    // Mouse controls for buttons
    upBtn.addEventListener('mousedown', () => { keysPressed['up'] = true; });
    upBtn.addEventListener('mouseup', () => { keysPressed['up'] = false; });
    downBtn.addEventListener('mousedown', () => { keysPressed['down'] = true; });
    downBtn.addEventListener('mouseup', () => { keysPressed['down'] = false; });
    
    // Start button - mark player as ready
    const startBtn = document.getElementById('startBtn');
    if (startBtn) {
        startBtn.addEventListener('click', () => {
            if (connectionEstablished && !localPlayerReady) {
                localPlayerReady = true;
                startBtn.disabled = true;
                startBtn.textContent = 'Waiting for opponent...';
                
                // Send ready message
                SpixiAppSdk.sendNetworkData(JSON.stringify({ a: "ready" }));
                lastDataSent = SpixiTools.getTimestamp();
                
                checkBothPlayersReady();
            }
        });
    }
    
    // Shoot button
    const shootBtn = document.getElementById('shootBtn');
    if (shootBtn) {
        shootBtn.addEventListener('click', () => {
            if (gameState.isBallOwner && gameState.ball.vx === 0) {
                launchBall();
            }
        });
    }
    
    // Restart button
    document.getElementById('restartBtn').addEventListener('click', restartGame);
    
    // Restart button during game
    const restartGameBtn = document.getElementById('restartGameBtn');
    if (restartGameBtn) {
        restartGameBtn.addEventListener('click', () => {
            if (gameState.gameStarted) {
                restartGame();
            }
        });
    }
    
    // Exit button
    const exitBtn = document.getElementById('exitBtn');
    if (exitBtn) {
        exitBtn.addEventListener('click', exitGame);
    }
}

function checkBothPlayersReady() {
    if (localPlayerReady && remotePlayerReady && !countdownActive) {
        startCountdown();
    }
}

function startCountdown() {
    countdownActive = true;
    document.getElementById('status-text').textContent = 'READY?';
    
    setTimeout(() => {
        countdownActive = false;
        startGame();
    }, 1000);
}

function startGame() {
    document.getElementById('startBtn').style.display = 'none';
    gameStartTime = Date.now();
    
    // Randomly determine who controls the ball
    const combinedId = sessionId + remotePlayerAddress;
    const hash = Array.from(combinedId).reduce((acc, char) => acc + char.charCodeAt(0), 0);
    gameState.isBallOwner = hash % 2 === (sessionId < remotePlayerAddress ? 0 : 1);
    
    // Show shoot button for both players
    const shootBtn = document.getElementById('shootBtn');
    shootBtn.style.display = 'inline-flex';
    
    if (gameState.isBallOwner) {
        document.getElementById('status-text').textContent = 'Launch Ball!';
        shootBtn.disabled = false;
    } else {
        document.getElementById('status-text').textContent = 'Opponent Serves...';
        shootBtn.disabled = true;
    }
    
    gameState.gameStarted = true;
    gameState.lastUpdate = Date.now();
    
    // Reset ball position and target
    gameState.ball.x = CANVAS_WIDTH / 2;
    gameState.ball.y = CANVAS_HEIGHT / 2;
    gameState.ball.vx = 0;
    gameState.ball.vy = 0;
    
    ballTarget.x = CANVAS_WIDTH / 2;
    ballTarget.y = CANVAS_HEIGHT / 2;
    ballTarget.vx = 0;
    ballTarget.vy = 0;
    
    // Reset sync state
    frameCounter = 0;
    lastSyncTime = Date.now();
    lastSentPaddleY = gameState.localPaddle.y;
    
    // Start game loop
    if (!gameLoopInterval) {
        gameLoopInterval = setInterval(gameLoop, 1000 / FRAME_RATE);
    }
}

function launchBall() {
    if (gameState.ball.vx === 0 && gameState.isBallOwner) {
        document.getElementById('shootBtn').style.display = 'none';
        document.getElementById('status-text').textContent = 'Game On!';
        
        // Initialize ball velocity
        const angle = (Math.random() * Math.PI / 3) - Math.PI / 6;
        const direction = Math.random() < 0.5 ? 1 : -1;
        gameState.ball.vx = Math.cos(angle) * BALL_SPEED_INITIAL * direction;
        gameState.ball.vy = Math.sin(angle) * BALL_SPEED_INITIAL;
        
        // Initialize target for smooth interpolation
        ballTarget.x = gameState.ball.x;
        ballTarget.y = gameState.ball.y;
        ballTarget.vx = gameState.ball.vx;
        ballTarget.vy = gameState.ball.vy;
        
        // Notify other player
        SpixiAppSdk.sendNetworkData(JSON.stringify({ a: "launch" }));
        lastDataSent = SpixiTools.getTimestamp();
        
        // Send initial game state immediately
        lastSyncTime = 0; // Force immediate sync
        sendGameState();
    }
}

function gameLoop() {
    if (!gameState.gameStarted || gameState.gameEnded) {
        return;
    }
    
    frameCounter++;
    updatePaddle();
    
    // Smooth interpolate remote paddle position
    gameState.remotePaddle.y += (remotePaddleTarget - gameState.remotePaddle.y) * PADDLE_LERP_FACTOR;
    
    // Ball owner updates ball physics
    if (gameState.isBallOwner) {
        if (gameState.ball.vx !== 0) {
            updateBall();
            checkCollisions();
            checkScore();
        }
    } else {
        // Non-owner: interpolate ball movement
        const ballHasVelocity = Math.abs(gameState.ball.vx) > 0.1 || Math.abs(gameState.ball.vy) > 0.1;
        const targetHasVelocity = Math.abs(ballTarget.vx) > 0.1 || Math.abs(ballTarget.vy) > 0.1;
        
        if (ballHasVelocity || targetHasVelocity) {
            interpolateBall();
        } else {
            // Ball is truly stationary - keep at target position
            gameState.ball.x = ballTarget.x;
            gameState.ball.y = ballTarget.y;
            gameState.ball.vx = 0;
            gameState.ball.vy = 0;
        }
    }
    
    render();
    
    // Send unified game state at consistent rate
    const currentTime = Date.now();
    const timeSinceLastSync = currentTime - lastSyncTime;
    
    if (timeSinceLastSync >= SYNC_RATE) {
        sendGameState();
        lastSyncTime = currentTime;
    }
}

function updatePaddle() {
    const moveUp = keysPressed['up'] || touchControlActive === 'up';
    const moveDown = keysPressed['down'] || touchControlActive === 'down';
    
    if (moveUp) {
        gameState.localPaddle.y = Math.max(0, gameState.localPaddle.y - PADDLE_SPEED);
    }
    if (moveDown) {
        gameState.localPaddle.y = Math.min(CANVAS_HEIGHT - PADDLE_HEIGHT, gameState.localPaddle.y + PADDLE_SPEED);
    }
}

function updateBall() {
    gameState.ball.x += gameState.ball.vx;
    gameState.ball.y += gameState.ball.vy;
    
    // Top and bottom wall collision
    if (gameState.ball.y <= BALL_SIZE / 2 || gameState.ball.y >= CANVAS_HEIGHT - BALL_SIZE / 2) {
        gameState.ball.vy = -gameState.ball.vy;
        gameState.ball.y = Math.max(BALL_SIZE / 2, Math.min(CANVAS_HEIGHT - BALL_SIZE / 2, gameState.ball.y));
    }
}

function interpolateBall() {
    // Advanced interpolation with prediction and smoothing
    const lerpFactor = 0.3; // Slower lerp for smoother visuals
    
    // Check if we have valid target velocity
    const hasVelocity = Math.abs(ballTarget.vx) > 0.1 || Math.abs(ballTarget.vy) > 0.1;
    
    if (hasVelocity) {
        // Calculate prediction based on velocity
        const predictedX = ballTarget.x + ballTarget.vx * 0.8;
        const predictedY = ballTarget.y + ballTarget.vy * 0.8;
        
        // Interpolate towards predicted position
        gameState.ball.x += (predictedX - gameState.ball.x) * lerpFactor;
        gameState.ball.y += (predictedY - gameState.ball.y) * lerpFactor;
        
        // Smooth velocity interpolation
        gameState.ball.vx += (ballTarget.vx - gameState.ball.vx) * lerpFactor;
        gameState.ball.vy += (ballTarget.vy - gameState.ball.vy) * lerpFactor;
    } else {
        // If no velocity in target, directly sync position
        gameState.ball.x = ballTarget.x;
        gameState.ball.y = ballTarget.y;
        gameState.ball.vx = ballTarget.vx;
        gameState.ball.vy = ballTarget.vy;
    }
    
    // Keep ball visible and in bounds
    gameState.ball.x = Math.max(BALL_SIZE, Math.min(CANVAS_WIDTH - BALL_SIZE, gameState.ball.x));
    gameState.ball.y = Math.max(BALL_SIZE, Math.min(CANVAS_HEIGHT - BALL_SIZE, gameState.ball.y));
}

function checkCollisions() {
    const localPaddleX = gameState.isLeftPlayer ? 20 : CANVAS_WIDTH - 20 - PADDLE_WIDTH;
    const remotePaddleX = gameState.isLeftPlayer ? CANVAS_WIDTH - 20 - PADDLE_WIDTH : 20;
    
    // Local paddle collision
    if (gameState.ball.x - BALL_SIZE / 2 <= localPaddleX + PADDLE_WIDTH &&
        gameState.ball.x + BALL_SIZE / 2 >= localPaddleX &&
        gameState.ball.y >= gameState.localPaddle.y &&
        gameState.ball.y <= gameState.localPaddle.y + PADDLE_HEIGHT) {
        
        gameState.ball.vx = Math.abs(gameState.ball.vx) * (gameState.isLeftPlayer ? 1 : -1);
        gameState.ball.vx += gameState.ball.vx > 0 ? BALL_SPEED_INCREMENT : -BALL_SPEED_INCREMENT;
        
        const relativeIntersectY = (gameState.localPaddle.y + PADDLE_HEIGHT / 2) - gameState.ball.y;
        gameState.ball.vy = -relativeIntersectY * 0.15;
        
        gameState.ball.x = localPaddleX + (gameState.isLeftPlayer ? PADDLE_WIDTH + BALL_SIZE / 2 : -BALL_SIZE / 2);
        sendBallState(); // Send ball state on collision
    }
    
    // Remote paddle collision
    if (gameState.ball.x - BALL_SIZE / 2 <= remotePaddleX + PADDLE_WIDTH &&
        gameState.ball.x + BALL_SIZE / 2 >= remotePaddleX &&
        gameState.ball.y >= gameState.remotePaddle.y &&
        gameState.ball.y <= gameState.remotePaddle.y + PADDLE_HEIGHT) {
        
        gameState.ball.vx = Math.abs(gameState.ball.vx) * (gameState.isLeftPlayer ? -1 : 1);
        gameState.ball.vx += gameState.ball.vx > 0 ? BALL_SPEED_INCREMENT : -BALL_SPEED_INCREMENT;
        
        const relativeIntersectY = (gameState.remotePaddle.y + PADDLE_HEIGHT / 2) - gameState.ball.y;
        gameState.ball.vy = -relativeIntersectY * 0.15;
        
        gameState.ball.x = remotePaddleX + (gameState.isLeftPlayer ? -BALL_SIZE / 2 : PADDLE_WIDTH + BALL_SIZE / 2);
        sendBallState(); // Send ball state on collision
    }
}

function checkScore() {
    if (gameState.ball.x < 0) {
        // Left player missed
        if (gameState.isLeftPlayer) {
            gameState.localPaddle.lives--;
        } else {
            gameState.remotePaddle.lives--;
        }
        updateLivesDisplay();
        
        if (gameState.localPaddle.lives <= 0 || gameState.remotePaddle.lives <= 0) {
            endGame(gameState.localPaddle.lives > 0);
        } else {
            resetBall();
            sendLifeUpdate();
        }
    } else if (gameState.ball.x > CANVAS_WIDTH) {
        // Right player missed
        if (gameState.isLeftPlayer) {
            gameState.remotePaddle.lives--;
        } else {
            gameState.localPaddle.lives--;
        }
        updateLivesDisplay();
        
        if (gameState.localPaddle.lives <= 0 || gameState.remotePaddle.lives <= 0) {
            endGame(gameState.localPaddle.lives > 0);
        } else {
            resetBall();
            sendLifeUpdate();
        }
    }
}

function resetBall() {
    gameState.ball.x = CANVAS_WIDTH / 2;
    gameState.ball.y = CANVAS_HEIGHT / 2;
    
    const angle = (Math.random() * Math.PI / 3) - Math.PI / 6;
    const direction = Math.random() < 0.5 ? 1 : -1;
    
    gameState.ball.vx = Math.cos(angle) * BALL_SPEED_INITIAL * direction;
    gameState.ball.vy = Math.sin(angle) * BALL_SPEED_INITIAL;
    
    // Reset target for smooth interpolation
    ballTarget.x = gameState.ball.x;
    ballTarget.y = gameState.ball.y;
    ballTarget.vx = gameState.ball.vx;
    ballTarget.vy = gameState.ball.vy;
    
    // Send updated state immediately
    lastSyncTime = 0;
    sendGameState();
}

function updateLivesDisplay() {
    document.getElementById('local-score').textContent = gameState.localPaddle.lives;
    document.getElementById('remote-score').textContent = gameState.remotePaddle.lives;
    
    // Update life dots
    const playerDots = document.querySelectorAll('.player-score .life-dot');
    const opponentDots = document.querySelectorAll('.opponent-score .life-dot');
    
    playerDots.forEach((dot, index) => {
        if (index < gameState.localPaddle.lives) {
            dot.classList.add('active');
        } else {
            dot.classList.remove('active');
        }
    });
    
    opponentDots.forEach((dot, index) => {
        if (index < gameState.remotePaddle.lives) {
            dot.classList.add('active');
        } else {
            dot.classList.remove('active');
        }
    });
}

function render() {
    // Clear canvas
    ctx.fillStyle = '#1a202c';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    
    // Draw center line
    ctx.strokeStyle = '#4a5568';
    ctx.lineWidth = 2;
    ctx.setLineDash([10, 10]);
    ctx.beginPath();
    ctx.moveTo(CANVAS_WIDTH / 2, 0);
    ctx.lineTo(CANVAS_WIDTH / 2, CANVAS_HEIGHT);
    ctx.stroke();
    ctx.setLineDash([]);
    
    // Draw paddles
    ctx.fillStyle = '#4299e1';
    const localPaddleX = gameState.isLeftPlayer ? 20 : CANVAS_WIDTH - 20 - PADDLE_WIDTH;
    ctx.fillRect(localPaddleX, gameState.localPaddle.y, PADDLE_WIDTH, PADDLE_HEIGHT);
    
    ctx.fillStyle = '#f56565';
    const remotePaddleX = gameState.isLeftPlayer ? CANVAS_WIDTH - 20 - PADDLE_WIDTH : 20;
    ctx.fillRect(remotePaddleX, gameState.remotePaddle.y, PADDLE_WIDTH, PADDLE_HEIGHT);
    
    // Draw ball
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(gameState.ball.x, gameState.ball.y, BALL_SIZE / 2, 0, Math.PI * 2);
    ctx.fill();
}

function endGame(won) {
    gameState.gameEnded = true;
    
    if (gameLoopInterval) {
        clearInterval(gameLoopInterval);
        gameLoopInterval = null;
    }
    
    // Calculate game duration
    const duration = Math.floor((Date.now() - gameStartTime) / 1000);
    const minutes = Math.floor(duration / 60);
    const seconds = duration % 60;
    const durationText = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    
    // Smooth transition to game over screen
    const gameScreen = document.getElementById('game-screen');
    const gameOverScreen = document.getElementById('game-over-screen');
    
    gameScreen.classList.remove('screen-active');
    gameScreen.classList.add('screen-hidden');
    gameOverScreen.classList.remove('screen-hidden');
    gameOverScreen.classList.add('screen-active');
    
    // Update result UI
    const resultText = document.getElementById('result-text');
    const resultIcon = document.getElementById('resultIcon');
    
    if (won) {
        resultText.textContent = 'Victory!';
        resultText.classList.add('victory');
        resultText.classList.remove('defeat');
        resultIcon.classList.add('victory');
        resultIcon.classList.remove('defeat');
        // Update icon to checkmark (already in HTML)
    } else {
        resultText.textContent = 'Defeat';
        resultText.classList.add('defeat');
        resultText.classList.remove('victory');
        resultIcon.classList.add('defeat');
        resultIcon.classList.remove('victory');
        // Update icon to X
        resultIcon.innerHTML = `
            <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" stroke-width="4"/>
                <path d="M35 35 L65 65 M65 35 L35 65" fill="none" stroke="currentColor" stroke-width="6" stroke-linecap="round"/>
            </svg>
        `;
    }
    
    document.getElementById('final-score').textContent = 
        `Final Score: ${gameState.localPaddle.lives} - ${gameState.remotePaddle.lives}`;
    document.getElementById('gameDuration').textContent = durationText;
    
    saveGameState();
    sendEndGame();
}

function restartGame() {
    gameState = {
        localPaddle: { y: CANVAS_HEIGHT / 2 - PADDLE_HEIGHT / 2, lives: MAX_LIVES },
        remotePaddle: { y: CANVAS_HEIGHT / 2 - PADDLE_HEIGHT / 2, lives: MAX_LIVES },
        ball: {
            x: CANVAS_WIDTH / 2,
            y: CANVAS_HEIGHT / 2,
            vx: 0,
            vy: 0
        },
        isBallOwner: gameState.isBallOwner,
        isLeftPlayer: gameState.isLeftPlayer,
        gameStarted: false,
        gameEnded: false,
        lastUpdate: 0
    };
    
    // Reset ball interpolation target
    ballTarget = {
        x: CANVAS_WIDTH / 2,
        y: CANVAS_HEIGHT / 2,
        vx: 0,
        vy: 0
    };
    
    localPlayerReady = false;
    remotePlayerReady = false;
    countdownActive = false;
    gameStartTime = 0;
    
    // Smooth screen transition
    const gameOverScreen = document.getElementById('game-over-screen');
    const gameScreen = document.getElementById('game-screen');
    
    gameOverScreen.classList.remove('screen-active');
    gameOverScreen.classList.add('screen-hidden');
    gameScreen.classList.remove('screen-hidden');
    gameScreen.classList.add('screen-active');
    
    // Update button states
    const startBtn = document.getElementById('startBtn');
    startBtn.style.display = 'inline-flex';
    startBtn.disabled = false;
    startBtn.querySelector('.btn-text').textContent = 'Start Game';
    document.getElementById('shootBtn').style.display = 'none';
    document.getElementById('status-text').textContent = 'Ready to Play!';
    
    updateLivesDisplay();
    
    if (remotePlayerAddress !== '') {
        SpixiAppSdk.sendNetworkData(JSON.stringify({ a: "restart" }));
        lastDataSent = SpixiTools.getTimestamp();
    }
}

function exitGame() {
    if (gameLoopInterval) {
        clearInterval(gameLoopInterval);
        gameLoopInterval = null;
    }
    if (pingInterval) {
        clearInterval(pingInterval);
        pingInterval = null;
    }
    if (autoStartTimer) {
        clearTimeout(autoStartTimer);
        autoStartTimer = null;
    }
    // Use spixiAction with "close" to properly exit webview
    SpixiAppSdk.spixiAction("close");
}

// Network functions - Unified game state sync
function sendGameState() {
    const currentTime = SpixiTools.getTimestamp();
    lastDataSent = currentTime;
    
    const paddleY = Math.round(gameState.localPaddle.y);
    const paddleMoved = Math.abs(paddleY - lastSentPaddleY) > 0;
    const ballActive = gameState.ball.vx !== 0;
    const isBallOwnerWithActiveBall = gameState.isBallOwner && ballActive;
    
    // Always send if ball is active (critical for sync), or if paddle moved
    if (!paddleMoved && !isBallOwnerWithActiveBall) {
        return; // Skip only if nothing is happening
    }
    
    lastSentPaddleY = paddleY;
    
    // Build unified state packet
    const state = {
        a: "state",
        f: frameCounter, // Frame number for sync
        p: paddleY // Paddle position
    };
    
    // Include ball data if this player owns the ball and it's active
    if (isBallOwnerWithActiveBall) {
        const b = gameState.ball;
        state.b = {
            x: Math.round(b.x),
            y: Math.round(b.y),
            vx: Number(b.vx.toFixed(2)),
            vy: Number(b.vy.toFixed(2))
        };
    }
    
    SpixiAppSdk.sendNetworkData(JSON.stringify(state));
}

function sendLifeUpdate() {
    const currentTime = SpixiTools.getTimestamp();
    lastDataSent = currentTime;
    SpixiAppSdk.sendNetworkData(JSON.stringify({
        a: "lives",
        local: gameState.localPaddle.lives,
        remote: gameState.remotePaddle.lives
    }));
}

function sendEndGame() {
    const currentTime = SpixiTools.getTimestamp();
    lastDataSent = currentTime;
    SpixiAppSdk.sendNetworkData(JSON.stringify({
        a: "end",
        local: gameState.localPaddle.lives,
        remote: gameState.remotePaddle.lives
    }));
}

function saveGameState() {
    // Save final game state for statistics/history (optional)
    if (remotePlayerAddress !== '') {
        setTimeout(() => {
            SpixiAppSdk.setStorageData(remotePlayerAddress, btoa(JSON.stringify(gameState)));
        }, 50);
    }
}

// Spixi SDK callbacks
SpixiAppSdk.onInit = function(sid, userAddresses) {
    sessionId = sid;
    const addresses = userAddresses.split(",");
    remotePlayerAddress = addresses[0];
    
    // Determine which side we're on (left or right)
    gameState.isLeftPlayer = sessionId < remotePlayerAddress;
    
    // Initialize game UI and start connection
    initGame();
    establishConnection();
    
    // Show waiting screen - always start with fresh game
    const waitingScreen = document.getElementById('waiting-screen');
    const gameScreen = document.getElementById('game-screen');
    waitingScreen.style.display = 'flex';
    gameScreen.style.display = 'none';
    
    const waitingText = document.querySelector('.waiting-text');
    if (waitingText) {
        waitingText.textContent = 'Connecting to opponent...';
    }
};

SpixiAppSdk.onNetworkData = function(senderAddress, data) {
    playerLastSeen = SpixiTools.getTimestamp();
    
    try {
        const msg = JSON.parse(data);
        
        switch(msg.a) {
            case "connect":
                // Received connection request, reply back
                if (!connectionEstablished) {
                    SpixiAppSdk.sendNetworkData(JSON.stringify({ a: "connect", sid: sessionId }));
                    lastDataSent = SpixiTools.getTimestamp();
                    handleConnectionEstablished();
                }
                break;
                
            case "ping":
                // Connection keepalive
                break;
                
            case "ready":
                remotePlayerReady = true;
                checkBothPlayersReady();
                break;
                
            case "launch":
                // Ball owner has launched - hide shoot button and update status
                if (!gameState.isBallOwner) {
                    document.getElementById('shootBtn').style.display = 'none';
                    document.getElementById('status-text').textContent = 'Game On!';
                }
                break;
                
            case "state": // Unified game state update
                // Update remote paddle target for smooth interpolation
                if (msg.p !== undefined) {
                    remotePaddleTarget = msg.p;
                }
                
                // Update ball state if included and we don't own the ball
                if (msg.b && !gameState.isBallOwner) {
                    // Always update target with latest data
                    ballTarget.x = msg.b.x;
                    ballTarget.y = msg.b.y;
                    ballTarget.vx = msg.b.vx;
                    ballTarget.vy = msg.b.vy;
                    
                    // Calculate distance for snap decision
                    const distance = Math.sqrt(
                        Math.pow(gameState.ball.x - msg.b.x, 2) + 
                        Math.pow(gameState.ball.y - msg.b.y, 2)
                    );
                    
                    // Snap if: ball just started, very far away, or current velocity is near zero
                    const currentSpeed = Math.sqrt(gameState.ball.vx * gameState.ball.vx + gameState.ball.vy * gameState.ball.vy);
                    if (currentSpeed < 0.5 || distance > 200) {
                        gameState.ball.x = msg.b.x;
                        gameState.ball.y = msg.b.y;
                        gameState.ball.vx = msg.b.vx;
                        gameState.ball.vy = msg.b.vy;
                    }
                }
                break;
                
            case "lives":
                // Update lives from ball owner
                if (!gameState.isBallOwner) {
                    gameState.localPaddle.lives = msg.remote;
                    gameState.remotePaddle.lives = msg.local;
                    updateLivesDisplay();
                }
                break;
                
            case "end":
                // Game ended
                if (!gameState.gameEnded) {
                    gameState.localPaddle.lives = msg.remote;
                    gameState.remotePaddle.lives = msg.local;
                    endGame(gameState.localPaddle.lives > 0);
                }
                break;
                
            case "restart":
                // Restart request
                if (gameState.gameEnded) {
                    restartGame();
                }
                break;
        }
    } catch (e) {
        console.error("Error parsing network data:", e);
    }
};

SpixiAppSdk.onStorageData = function(key, value) {
    // Storage is only used to save final game state
    // Don't restore old game state on startup - always start fresh
    if (value !== 'null') {
        try {
            const savedState = JSON.parse(atob(value));
            // Ignore saved state - we always want to start a new game
            console.log("Previous game state found but ignored - starting fresh");
        } catch (e) {
            console.error("Error parsing saved state:", e);
        }
    }
};

// Start the app on load
window.onload = SpixiAppSdk.fireOnLoad;
