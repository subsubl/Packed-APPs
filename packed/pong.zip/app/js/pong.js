// Copyright (C) 2025 Baracuda
// Pong - A fast-paced multiplayer game for Spixi Mini Apps

// Game constants
const CANVAS_WIDTH = 800;
const CANVAS_HEIGHT = 600;
const PADDLE_WIDTH = 15;
const PADDLE_HEIGHT = 100;
const BALL_SIZE = 12;
const PADDLE_SPEED = 8;
const BALL_SPEED_INITIAL = 6;
const BALL_SPEED_INCREMENT = 0.3;
const MAX_LIVES = 3;
const FRAME_RATE = 60; // Render at 60fps
const NETWORK_SEND_RATE = 100; // Send network updates at 10fps (100ms)

// Game state
let gameState = {
    localPaddle: { y: CANVAS_HEIGHT / 2 - PADDLE_HEIGHT / 2, lives: MAX_LIVES },
    remotePaddle: { y: CANVAS_HEIGHT / 2 - PADDLE_HEIGHT / 2, lives: MAX_LIVES },
    ball: {
        x: CANVAS_WIDTH / 2,
        y: CANVAS_HEIGHT / 2,
        vx: 0,
        vy: 0
    },
    isBallOwner: false, // Who controls the ball (randomly assigned)
    gameStarted: false,
    gameEnded: false,
    lastUpdate: 0
};

// Ball interpolation state for smooth sync
let ballTarget = {
    x: CANVAS_WIDTH / 2,
    y: CANVAS_HEIGHT / 2,
    vx: 0,
    vy: 0
};
let ballInterpolationSpeed = 0.5; // Higher = faster catch-up
let lastBallUpdate = Date.now();

// Ball dead reckoning state for prediction between network updates
let ballLastKnownPosition = {
    x: CANVAS_WIDTH / 2,
    y: CANVAS_HEIGHT / 2,
    vx: 0,
    vy: 0,
    timestamp: Date.now()
};
let ballDeadReckoningActive = false; // Whether we're predicting ball position locally

// Ball interpolation state for smooth remote ball movement
let ballInterpolationLastPosition = {
    x: CANVAS_WIDTH / 2,
    y: CANVAS_HEIGHT / 2
};
let ballInterpolationLastUpdateTime = Date.now();
let ballInterpolationLerpFactor = 0.15; // Lerp factor for smooth ball interpolation (lower = smoother)

// Paddle interpolation for smooth remote paddle (60fps rendering from 10fps network data)
let remotePaddleTarget = CANVAS_HEIGHT / 2 - PADDLE_HEIGHT / 2;
const PADDLE_LERP_FACTOR = 0.25; // Slower lerp for smooth 60fps interpolation from 10fps data

// Entity interpolation state for remote paddle
let remotePaddleLastPosition = CANVAS_HEIGHT / 2 - PADDLE_HEIGHT / 2; // Previous known position
let remotePaddleLastUpdateTime = Date.now(); // Timestamp of last position update
let remotePaddleInterpolating = false; // Whether we're currently interpolating

let canvas, ctx;
let remotePlayerAddress = '';
let sessionId = '';
let playerLastSeen = 0;
let lastDataSent = 0;
let lastSyncTime = 0;
let frameCounter = 0;
let lastSentPaddleY = 0;
let keysPressed = {};
let touchControlActive = null;
let connectionEstablished = false;

// Input sequence tracking for server reconciliation
let inputSequence = 0; // Increments for each input sent
let lastAcknowledgedSequence = 0; // Last sequence confirmed by remote player
let pendingInputs = []; // Buffer of inputs not yet acknowledged

// Client-side prediction state
let predictedPaddleY = CANVAS_HEIGHT / 2 - PADDLE_HEIGHT / 2; // Local paddle predicted position
let lastAuthorativePaddleY = CANVAS_HEIGHT / 2 - PADDLE_HEIGHT / 2; // Last position confirmed by remote
let lastAuthorativeSequence = 0; // Last sequence number we received from remote

// Random number exchange for ball owner determination
let myRandomNumber = Math.floor(Math.random() * 1000);
let remoteRandomNumber = null;

// Connection quality monitoring
let packetReceiveCount = 0;
let lastPacketRateCheck = Date.now();
let currentPacketRate = 0;
let connectionQuality = 'good'; // 'good', 'fair', 'poor'
let autoStartTimer = null;
let gameStartTime = 0;

// Network ping interval
let pingInterval = null;
let gameLoopInterval = null;

// Simplified connection handshake
function establishConnection() {
    // Send connection request with session ID and random number for ball owner determination
    const msg = { a: "connect", sid: sessionId, rand: myRandomNumber };
    SpixiAppSdk.sendNetworkData(JSON.stringify(msg));
    lastDataSent = SpixiTools.getTimestamp();
}

function handleConnectionEstablished() {
    connectionEstablished = true;
    
    // Update connection status
    const statusLabel = document.querySelector('.status-label');
    if (statusLabel) {
        statusLabel.textContent = 'Connected';
    }
    
    // Start regular ping
    if (!pingInterval) {
        pingInterval = setInterval(() => {
            const currentTime = SpixiTools.getTimestamp();
            if (currentTime - lastDataSent >= 2) {
                lastDataSent = currentTime;
                SpixiAppSdk.sendNetworkData(JSON.stringify({ a: "ping" }));
            }
        }, 2000);
    }
    
    // Transition to game screen
    document.getElementById('waiting-screen').classList.replace('screen-active', 'screen-hidden');
    document.getElementById('game-screen').classList.replace('screen-hidden', 'screen-active');
    
    // Auto-start after brief delay
    autoStartTimer = setTimeout(() => startGame(), 500);
}

function initGame() {
    canvas = document.getElementById('pongCanvas');
    ctx = canvas.getContext('2d');
    canvas.width = CANVAS_WIDTH;
    canvas.height = CANVAS_HEIGHT;
    
    setupControls();
    
    // Show waiting screen initially with modern classes
    const waitingScreen = document.getElementById('waiting-screen');
    waitingScreen.classList.add('screen-active');
    waitingScreen.classList.remove('screen-hidden');
    
    updateLivesDisplay();
}

function setupControls() {
    // Keyboard controls
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
            keysPressed['up'] = true;
            e.preventDefault();
        }
        if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') {
            keysPressed['down'] = true;
            e.preventDefault();
        }
    });
    
    document.addEventListener('keyup', (e) => {
        if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
            keysPressed['up'] = false;
        }
        if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') {
            keysPressed['down'] = false;
        }
    });
    
    // Touch controls
    const upBtn = document.getElementById('upBtn');
    const downBtn = document.getElementById('downBtn');
    
    upBtn.addEventListener('touchstart', (e) => {
        e.preventDefault();
        touchControlActive = 'up';
    });
    
    upBtn.addEventListener('touchend', (e) => {
        e.preventDefault();
        touchControlActive = null;
    });
    
    downBtn.addEventListener('touchstart', (e) => {
        e.preventDefault();
        touchControlActive = 'down';
    });
    
    downBtn.addEventListener('touchend', (e) => {
        e.preventDefault();
        touchControlActive = null;
    });
    
    // Mouse controls for buttons
    upBtn.addEventListener('mousedown', () => { keysPressed['up'] = true; });
    upBtn.addEventListener('mouseup', () => { keysPressed['up'] = false; });
    downBtn.addEventListener('mousedown', () => { keysPressed['down'] = true; });
    downBtn.addEventListener('mouseup', () => { keysPressed['down'] = false; });
    
    // Start button - mark player as ready
    // Start button - removed, game auto-starts on connection
    
    // Shoot button
    const shootBtn = document.getElementById('shootBtn');
    if (shootBtn) {
        shootBtn.addEventListener('click', () => {
            if (gameState.isBallOwner && gameState.ball.vx === 0) {
                launchBall();
            }
        });
    }
    
    // Restart button
    document.getElementById('restartBtn').addEventListener('click', restartGame);
    
    // Restart button during game
    const restartGameBtn = document.getElementById('restartGameBtn');
    if (restartGameBtn) {
        restartGameBtn.addEventListener('click', () => {
            if (gameState.gameStarted) {
                restartGame();
            }
        });
    }
    
    // Exit button
    const exitBtn = document.getElementById('exitBtn');
    if (exitBtn) {
        exitBtn.addEventListener('click', exitGame);
    }
}

function startGame() {
    gameStartTime = Date.now();
    gameState.gameStarted = true;
    
    // Determine ball owner based on random number comparison
    // Higher number wins. If equal (rare), compare session IDs
    if (myRandomNumber === remoteRandomNumber) {
        gameState.isBallOwner = sessionId > remotePlayerAddress;
    } else {
        gameState.isBallOwner = myRandomNumber > remoteRandomNumber;
    }
    
    // Update UI
    document.getElementById('startBtn').style.display = 'none';
    const shootBtn = document.getElementById('shootBtn');
    shootBtn.style.display = 'inline-flex';
    shootBtn.disabled = !gameState.isBallOwner;
    document.getElementById('status-text').textContent = gameState.isBallOwner ? 'Launch Ball!' : 'Opponent Serves...';
    
    // Reset game state
    resetBallPosition();
    
    // Initialize client-side prediction state
    predictedPaddleY = gameState.localPaddle.y;
    lastAuthorativePaddleY = gameState.localPaddle.y;
    lastAuthorativeSequence = 0;
    
    frameCounter = 0;
    lastSyncTime = Date.now();
    
    // Start game loop
    if (!gameLoopInterval) {
        gameLoopInterval = setInterval(gameLoop, 1000 / FRAME_RATE);
    }
}

function resetBallPosition() {
    gameState.ball.x = CANVAS_WIDTH / 2;
    gameState.ball.y = CANVAS_HEIGHT / 2;
    gameState.ball.vx = 0;
    gameState.ball.vy = 0;
    
    ballTarget.x = CANVAS_WIDTH / 2;
    ballTarget.y = CANVAS_HEIGHT / 2;
    ballTarget.vx = 0;
    ballTarget.vy = 0;
}

function launchBall() {
    if (gameState.ball.vx === 0 && gameState.isBallOwner) {
        document.getElementById('shootBtn').style.display = 'none';
        document.getElementById('status-text').textContent = 'Game On!';
        
        // Initialize ball velocity
        const angle = (Math.random() * Math.PI / 3) - Math.PI / 6;
        const direction = Math.random() < 0.5 ? 1 : -1;
        gameState.ball.vx = Math.cos(angle) * BALL_SPEED_INITIAL * direction;
        gameState.ball.vy = Math.sin(angle) * BALL_SPEED_INITIAL;
        
        // Sync target with actual
        ballTarget.x = gameState.ball.x;
        ballTarget.y = gameState.ball.y;
        ballTarget.vx = gameState.ball.vx;
        ballTarget.vy = gameState.ball.vy;
        
        // Notify other player and sync immediately
        SpixiAppSdk.sendNetworkData(JSON.stringify({ a: "launch" }));
        lastDataSent = SpixiTools.getTimestamp();
        lastSyncTime = 0;
        sendGameState();
    }
}

function gameLoop() {
    if (!gameState.gameStarted || gameState.gameEnded) {
        return;
    }
    
    frameCounter++;
    updatePaddle();
    
    // Update remote paddle with entity interpolation
    updateRemotePaddleInterpolation();
    
    // Both players simulate ball movement using current velocity
    const ballHasVelocity = Math.abs(gameState.ball.vx) > 0.1 || Math.abs(gameState.ball.vy) > 0.1;
    
    if (ballHasVelocity) {
        updateBall();
        
        // Apply ball dead reckoning to stay in sync between network updates
        updateBallDeadReckoning();
        
        // Apply ball interpolation for smooth remote ball movement
        updateBallInterpolation();
        
        checkCollisions();
        
        // Only ball owner checks score (game logic authority)
        if (gameState.isBallOwner) {
            checkScore();
        }
    }
    
    render();
    
    // Send unified game state at 10fps (every 100ms)
    const currentTime = Date.now();
    const timeSinceLastSync = currentTime - lastSyncTime;
    
    if (timeSinceLastSync >= NETWORK_SEND_RATE) {
        sendGameState();
        lastSyncTime = currentTime;
    }
}

function updatePaddle() {
    const moveUp = keysPressed['up'] || touchControlActive === 'up';
    const moveDown = keysPressed['down'] || touchControlActive === 'down';
    
    // Client-side prediction: Apply input immediately to predicted state
    // This eliminates the lag between user input and visual response
    if (moveUp) {
        predictedPaddleY = Math.max(0, predictedPaddleY - PADDLE_SPEED);
    }
    if (moveDown) {
        predictedPaddleY = Math.min(CANVAS_HEIGHT - PADDLE_HEIGHT, predictedPaddleY + PADDLE_SPEED);
    }
    
    // Use predicted paddle position for rendering and collision detection
    gameState.localPaddle.y = predictedPaddleY;
}

/**
 * Entity interpolation for remote paddle: Smooth movement between known positions
 * 
 * The server sends paddle updates at 10fps, but we render at 60fps.
 * Instead of showing jumpy movement, we interpolate between the last known position
 * and the current target position using linear interpolation (lerp).
 * 
 * This technique is essential for smooth gameplay when network updates arrive infrequently.
 * The lerp factor determines how quickly we reach the target position.
 */
function updateRemotePaddleInterpolation() {
    const currentTime = Date.now();
    
    // If we have a new target, update interpolation state
    if (remotePaddleTarget !== gameState.remotePaddle.y) {
        remotePaddleInterpolating = true;
        remotePaddleLastPosition = gameState.remotePaddle.y;
        remotePaddleLastUpdateTime = currentTime;
    }
    
    if (remotePaddleInterpolating) {
        // Smoothly lerp from current position toward target
        // PADDLE_LERP_FACTOR of 0.25 means we cover 25% of remaining distance each frame
        // At 60fps, this creates smooth motion between 10fps network updates
        gameState.remotePaddle.y += (remotePaddleTarget - gameState.remotePaddle.y) * PADDLE_LERP_FACTOR;
        
        // Stop interpolating when we're very close to target (within 1 pixel)
        if (Math.abs(gameState.remotePaddle.y - remotePaddleTarget) < 1) {
            gameState.remotePaddle.y = remotePaddleTarget;
            remotePaddleInterpolating = false;
        }
    }
}

function updateBall() {
    gameState.ball.x += gameState.ball.vx;
    gameState.ball.y += gameState.ball.vy;
    
    // Top and bottom wall collision
    if (gameState.ball.y <= BALL_SIZE / 2 || gameState.ball.y >= CANVAS_HEIGHT - BALL_SIZE / 2) {
        gameState.ball.vy = -gameState.ball.vy;
        gameState.ball.y = Math.max(BALL_SIZE / 2, Math.min(CANVAS_HEIGHT - BALL_SIZE / 2, gameState.ball.y));
    }
}

/**
 * Ball dead reckoning: Predict ball position based on last known state
 * 
 * Dead reckoning is a technique where we estimate an object's future position
 * based on its last known position and velocity. This is especially useful for
 * objects with predictable motion like a bouncing ball.
 * 
 * The server sends ball updates at 10fps, but we render at 60fps.
 * Instead of leaving the ball stationary between updates, we predict where it should be
 * based on its velocity, then correct when the next update arrives.
 * 
 * This keeps the ball moving smoothly and continuously even between network updates.
 */
function updateBallDeadReckoning() {
    if (!ballDeadReckoningActive) {
        return; // Only apply dead reckoning when ball is actively moving
    }
    
    const currentTime = Date.now();
    const timeSinceLastUpdate = (currentTime - ballLastKnownPosition.timestamp) / 1000; // Convert to seconds
    
    // Predict ball position based on constant velocity
    // This assumes the ball will continue with the same velocity until the next network update
    const predictedX = ballLastKnownPosition.x + (ballLastKnownPosition.vx * timeSinceLastUpdate);
    const predictedY = ballLastKnownPosition.y + (ballLastKnownPosition.vy * timeSinceLastUpdate);
    
    // Only update if prediction significantly differs from current position
    // This prevents minor jitter from dead reckoning corrections
    const distanceDiff = Math.sqrt(
        Math.pow(gameState.ball.x - predictedX, 2) + 
        Math.pow(gameState.ball.y - predictedY, 2)
    );
    
    // If prediction differs by more than 5 pixels, use it (indicates drift)
    // Otherwise, let normal ball physics handle the motion
    if (distanceDiff > 5) {
        gameState.ball.x = predictedX;
        gameState.ball.y = predictedY;
    }
}

/**
 * Ball interpolation with velocity adjustment: Smooth ball movement between network updates
 * 
 * This technique combines position interpolation with velocity-based adjustments.
 * When new ball data arrives, we update velocity and smoothly lerp to the new position.
 * 
 * Key features:
 * - Velocity snapping: If velocity changes >0.1, snap to match remote player's view
 * - Stop detection: If remote ball velocity drops below 0.5, consider it stopped
 * - Position snapping: If distance >200px (large jump), snap instead of lerp
 * - Smooth interpolation: Otherwise, lerp toward new position for smooth motion
 * 
 * This creates a seamless experience where the ball appears to move continuously
 * even though we only receive updates 10 times per second.
 */
function updateBallInterpolation() {
    // Smooth interpolation toward target position
    const distanceToTarget = Math.sqrt(
        Math.pow(gameState.ball.x - ballTarget.x, 2) + 
        Math.pow(gameState.ball.y - ballTarget.y, 2)
    );
    
    // Snap to target if far away (>200px indicates major position correction)
    if (distanceToTarget > 200) {
        gameState.ball.x = ballTarget.x;
        gameState.ball.y = ballTarget.y;
        gameState.ball.vx = ballTarget.vx;
        gameState.ball.vy = ballTarget.vy;
    } else if (distanceToTarget > 1) {
        // Lerp smoothly toward target position
        // ballInterpolationLerpFactor of 0.15 creates smooth motion over ~40ms
        gameState.ball.x += (ballTarget.x - gameState.ball.x) * ballInterpolationLerpFactor;
        gameState.ball.y += (ballTarget.y - gameState.ball.y) * ballInterpolationLerpFactor;
        
        // Gradually adjust velocity toward target velocity
        const velocityDiff = Math.sqrt(
            Math.pow(gameState.ball.vx - ballTarget.vx, 2) + 
            Math.pow(gameState.ball.vy - ballTarget.vy, 2)
        );
        
        // Snap velocity if significant change detected (indicates bounce/collision)
        if (velocityDiff > 0.1) {
            gameState.ball.vx = ballTarget.vx;
            gameState.ball.vy = ballTarget.vy;
        } else if (velocityDiff > 0) {
            // Smoothly interpolate velocity
            gameState.ball.vx += (ballTarget.vx - gameState.ball.vx) * 0.1;
            gameState.ball.vy += (ballTarget.vy - gameState.ball.vy) * 0.1;
        }
    } else {
        // Very close to target, snap to it
        gameState.ball.x = ballTarget.x;
        gameState.ball.y = ballTarget.y;
    }
    
    // Stop detection: If velocity is very low (<0.5), consider ball stopped
    if (Math.abs(gameState.ball.vx) < 0.5 && Math.abs(gameState.ball.vy) < 0.5) {
        gameState.ball.vx = 0;
        gameState.ball.vy = 0;
    }
}

function checkCollisions() {
    // Ball owner always on right side
    const rightPaddleX = CANVAS_WIDTH - 20 - PADDLE_WIDTH;
    const leftPaddleX = 20;
    
    let rightPaddleY, leftPaddleY;
    if (gameState.isBallOwner) {
        rightPaddleY = gameState.localPaddle.y;
        leftPaddleY = gameState.remotePaddle.y;
    } else {
        rightPaddleY = gameState.remotePaddle.y;
        leftPaddleY = gameState.localPaddle.y;
    }
    
    // Right paddle collision (ball owner)
    if (gameState.ball.x + BALL_SIZE / 2 >= rightPaddleX &&
        gameState.ball.x - BALL_SIZE / 2 <= rightPaddleX + PADDLE_WIDTH &&
        gameState.ball.y >= rightPaddleY &&
        gameState.ball.y <= rightPaddleY + PADDLE_HEIGHT) {
        
        gameState.ball.vx = -Math.abs(gameState.ball.vx); // Bounce left
        gameState.ball.vx += gameState.ball.vx > 0 ? BALL_SPEED_INCREMENT : -BALL_SPEED_INCREMENT;
        
        const relativeIntersectY = (rightPaddleY + PADDLE_HEIGHT / 2) - gameState.ball.y;
        gameState.ball.vy = -relativeIntersectY * 0.15;
        
        gameState.ball.x = rightPaddleX - BALL_SIZE / 2;
        sendBallState(); // Send ball state on collision
    }
    
    // Left paddle collision (non-owner)
    if (gameState.ball.x - BALL_SIZE / 2 <= leftPaddleX + PADDLE_WIDTH &&
        gameState.ball.x + BALL_SIZE / 2 >= leftPaddleX &&
        gameState.ball.y >= leftPaddleY &&
        gameState.ball.y <= leftPaddleY + PADDLE_HEIGHT) {
        
        gameState.ball.vx = Math.abs(gameState.ball.vx); // Bounce right
        gameState.ball.vx += gameState.ball.vx > 0 ? BALL_SPEED_INCREMENT : -BALL_SPEED_INCREMENT;
        
        const relativeIntersectY = (leftPaddleY + PADDLE_HEIGHT / 2) - gameState.ball.y;
        gameState.ball.vy = -relativeIntersectY * 0.15;
        
        gameState.ball.x = leftPaddleX + PADDLE_WIDTH + BALL_SIZE / 2;
        sendBallState(); // Send ball state on collision
    }
}

function checkScore() {
    if (gameState.ball.x < 0) {
        // Left side (non-owner) missed
        if (gameState.isBallOwner) {
            gameState.remotePaddle.lives--;
        } else {
            gameState.localPaddle.lives--;
        }
        updateLivesDisplay();
        
        if (gameState.localPaddle.lives <= 0 || gameState.remotePaddle.lives <= 0) {
            endGame(gameState.localPaddle.lives > 0);
        } else {
            resetBall();
            sendLifeUpdate();
        }
    } else if (gameState.ball.x > CANVAS_WIDTH) {
        // Right side (ball owner) missed
        if (gameState.isBallOwner) {
            gameState.localPaddle.lives--;
        } else {
            gameState.remotePaddle.lives--;
        }
        updateLivesDisplay();
        
        if (gameState.localPaddle.lives <= 0 || gameState.remotePaddle.lives <= 0) {
            endGame(gameState.localPaddle.lives > 0);
        } else {
            resetBall();
            sendLifeUpdate();
        }
    }
}

function resetBall() {
    // Reset to center
    resetBallPosition();
    
    // Launch ball with random velocity
    const angle = (Math.random() * Math.PI / 3) - Math.PI / 6;
    const direction = Math.random() < 0.5 ? 1 : -1;
    gameState.ball.vx = Math.cos(angle) * BALL_SPEED_INITIAL * direction;
    gameState.ball.vy = Math.sin(angle) * BALL_SPEED_INITIAL;
    
    // Sync target
    ballTarget.vx = gameState.ball.vx;
    ballTarget.vy = gameState.ball.vy;
    
    // Send immediately
    lastSyncTime = 0;
    sendGameState();
}

function updateLivesDisplay() {
    document.getElementById('local-score').textContent = gameState.localPaddle.lives;
    document.getElementById('remote-score').textContent = gameState.remotePaddle.lives;
    
    // Update life dots
    const playerDots = document.querySelectorAll('.player-score .life-dot');
    const opponentDots = document.querySelectorAll('.opponent-score .life-dot');
    
    playerDots.forEach((dot, index) => {
        if (index < gameState.localPaddle.lives) {
            dot.classList.add('active');
        } else {
            dot.classList.remove('active');
        }
    });
    
    opponentDots.forEach((dot, index) => {
        if (index < gameState.remotePaddle.lives) {
            dot.classList.add('active');
        } else {
            dot.classList.remove('active');
        }
    });
}

function render() {
    // Clear canvas
    ctx.fillStyle = '#1a202c';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    
    // Draw center line
    ctx.strokeStyle = '#4a5568';
    ctx.lineWidth = 2;
    ctx.setLineDash([10, 10]);
    ctx.beginPath();
    ctx.moveTo(CANVAS_WIDTH / 2, 0);
    ctx.lineTo(CANVAS_WIDTH / 2, CANVAS_HEIGHT);
    ctx.stroke();
    ctx.setLineDash([]);
    
    // Draw connection quality indicator (top right)
    if (connectionEstablished && gameState.gameStarted) {
        ctx.save();
        ctx.font = '12px Arial';
        ctx.textAlign = 'right';
        
        // Color based on quality
        if (connectionQuality === 'good') {
            ctx.fillStyle = '#48bb78'; // green
        } else if (connectionQuality === 'fair') {
            ctx.fillStyle = '#ed8936'; // orange
        } else {
            ctx.fillStyle = '#f56565'; // red
        }
        
        // Draw indicator dot and text
        ctx.fillRect(CANVAS_WIDTH - 15, 10, 8, 8);
        ctx.fillText(`${currentPacketRate} pps`, CANVAS_WIDTH - 25, 16);
        ctx.restore();
    }
    
    // Draw paddles - ball owner always on right side
    // If I own ball: I'm on right (red), opponent on left (blue)
    // If opponent owns ball: opponent on right (red), I'm on left (blue)
    
    let rightPaddleY, leftPaddleY, rightPaddleColor, leftPaddleColor;
    
    if (gameState.isBallOwner) {
        // I own ball - I'm on right (red)
        rightPaddleY = gameState.localPaddle.y;
        leftPaddleY = gameState.remotePaddle.y;
        rightPaddleColor = '#f56565'; // Red for ball owner
        leftPaddleColor = '#4299e1';  // Blue for non-owner
    } else {
        // Opponent owns ball - opponent on right (red)
        rightPaddleY = gameState.remotePaddle.y;
        leftPaddleY = gameState.localPaddle.y;
        rightPaddleColor = '#f56565'; // Red for ball owner
        leftPaddleColor = '#4299e1';  // Blue for non-owner
    }
    
    const rightPaddleX = CANVAS_WIDTH - 20 - PADDLE_WIDTH;
    const leftPaddleX = 20;
    
    // Draw right paddle (ball owner)
    ctx.fillStyle = rightPaddleColor;
    ctx.fillRect(rightPaddleX, rightPaddleY, PADDLE_WIDTH, PADDLE_HEIGHT);
    
    // Draw left paddle (non-owner)
    ctx.fillStyle = leftPaddleColor;
    ctx.fillRect(leftPaddleX, leftPaddleY, PADDLE_WIDTH, PADDLE_HEIGHT);
    
    // Draw ball - always white
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(gameState.ball.x, gameState.ball.y, BALL_SIZE / 2, 0, Math.PI * 2);
    ctx.fill();
}

function endGame(won) {
    gameState.gameEnded = true;
    
    if (gameLoopInterval) {
        clearInterval(gameLoopInterval);
        gameLoopInterval = null;
    }
    
    // Calculate game duration
    const duration = Math.floor((Date.now() - gameStartTime) / 1000);
    const minutes = Math.floor(duration / 60);
    const seconds = duration % 60;
    const durationText = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    
    // Smooth transition to game over screen
    const gameScreen = document.getElementById('game-screen');
    const gameOverScreen = document.getElementById('game-over-screen');
    
    gameScreen.classList.remove('screen-active');
    gameScreen.classList.add('screen-hidden');
    gameOverScreen.classList.remove('screen-hidden');
    gameOverScreen.classList.add('screen-active');
    
    // Update result UI
    const resultText = document.getElementById('result-text');
    const resultIcon = document.getElementById('resultIcon');
    
    if (won) {
        resultText.textContent = 'Victory!';
        resultText.classList.add('victory');
        resultText.classList.remove('defeat');
        resultIcon.classList.add('victory');
        resultIcon.classList.remove('defeat');
        // Update icon to checkmark (already in HTML)
    } else {
        resultText.textContent = 'Defeat';
        resultText.classList.add('defeat');
        resultText.classList.remove('victory');
        resultIcon.classList.add('defeat');
        resultIcon.classList.remove('victory');
        // Update icon to X
        resultIcon.innerHTML = `
            <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" stroke-width="4"/>
                <path d="M35 35 L65 65 M65 35 L35 65" fill="none" stroke="currentColor" stroke-width="6" stroke-linecap="round"/>
            </svg>
        `;
    }
    
    document.getElementById('final-score').textContent = 
        `Final Score: ${gameState.localPaddle.lives} - ${gameState.remotePaddle.lives}`;
    document.getElementById('gameDuration').textContent = durationText;
    
    saveGameState();
    sendEndGame();
}

function restartGame() {
    // Reset game state
    gameState.localPaddle.y = CANVAS_HEIGHT / 2 - PADDLE_HEIGHT / 2;
    gameState.localPaddle.lives = MAX_LIVES;
    gameState.remotePaddle.y = CANVAS_HEIGHT / 2 - PADDLE_HEIGHT / 2;
    gameState.remotePaddle.lives = MAX_LIVES;
    gameState.gameStarted = false;
    gameState.gameEnded = false;
    
    resetBallPosition();
    updateLivesDisplay();
    
    // Transition screens
    document.getElementById('game-over-screen').classList.replace('screen-active', 'screen-hidden');
    document.getElementById('game-screen').classList.replace('screen-hidden', 'screen-active');
    
    // Notify remote player and auto-start
    SpixiAppSdk.sendNetworkData(JSON.stringify({ a: "restart" }));
    lastDataSent = SpixiTools.getTimestamp();
    setTimeout(() => startGame(), 500);
}

function exitGame() {
    // Cleanup intervals
    if (gameLoopInterval) clearInterval(gameLoopInterval);
    if (pingInterval) clearInterval(pingInterval);
    if (autoStartTimer) clearTimeout(autoStartTimer);
    
    // Close app
    SpixiAppSdk.spixiAction("close");
}

// Network functions - Unified game state sync at 10fps (100ms intervals)
function sendGameState() {
    if (!gameState.gameStarted || gameState.gameEnded) {
        return; // Don't send if game not active
    }
    
    const currentTime = SpixiTools.getTimestamp();
    lastDataSent = currentTime;
    
    // Use predicted paddle position (client-side prediction)
    const paddleY = Math.round(predictedPaddleY);
    
    // Check if paddle position changed since last send
    const paddleChanged = paddleY !== lastSentPaddleY;
    
    // If paddle position changed, assign new sequence number and store in buffer
    if (paddleChanged) {
        inputSequence++;
        const input = {
            seq: inputSequence,
            paddleY: paddleY,
            timestamp: currentTime
        };
        pendingInputs.push(input);
        lastSentPaddleY = paddleY;
    }
    
    // Build unified state packet with paddle (always) and sequence info
    const state = {
        a: "state",
        f: frameCounter, // Frame number for sync
        p: paddleY, // Paddle position (always included)
        seq: inputSequence, // Current input sequence number
        lastAck: lastAcknowledgedSequence // Echo back last sequence we acknowledged from remote
    };
    
    // Send ball data if ball is moving toward my side
    const ballActive = Math.abs(gameState.ball.vx) > 0.1 || Math.abs(gameState.ball.vy) > 0.1;
    
    // Determine which side ball is moving toward based on velocity
    let ballMovingTowardMe = false;
    if (gameState.isBallOwner) {
        // Ball owner on right - ball coming toward me if vx > 0 (moving right)
        ballMovingTowardMe = gameState.ball.vx > 0;
    } else {
        // Non-owner on left - ball coming toward me if vx < 0 (moving left)
        ballMovingTowardMe = gameState.ball.vx < 0;
    }
    
    if (ballActive && ballMovingTowardMe) {
        const b = gameState.ball;
        // Mirror X coordinates for opponent's view (they see from opposite side)
        state.b = {
            x: Math.round(CANVAS_WIDTH - b.x),
            y: Math.round(b.y),
            vx: Number((-b.vx).toFixed(2)),
            vy: Number(b.vy.toFixed(2))
        };
    }
    
    SpixiAppSdk.sendNetworkData(JSON.stringify(state));
}

/**
 * Server reconciliation: Recompute paddle position from authoritative state + unacknowledged inputs
 * Called when receiving state update from remote player with their last acknowledged sequence.
 * This ensures smooth gameplay even when inputs arrive out of order or are delayed.
 * 
 * Process:
 * 1. Receive remote's acknowledgment of which inputs they processed (lastAckSeq)
 * 2. Accept their authoritative paddle position (authPaddleY)
 * 3. Replay all pending inputs that came after their acknowledgment
 * 4. Result: our predicted state stays in sync with their authoritative view
 */
function reconcilePaddleState(authPaddleY, lastAckSeq) {
    // Update with authoritative state from remote player
    lastAuthorativePaddleY = authPaddleY;
    lastAuthorativeSequence = lastAckSeq;
    
    // Set predicted position to authoritative, then replay unacknowledged inputs
    predictedPaddleY = authPaddleY;
    
    // Replay all inputs not yet acknowledged by remote
    for (const input of pendingInputs) {
        if (input.seq > lastAckSeq) {
            // Recalculate paddle position as if this input were applied to authoritative state
            // This simulates what the remote player will see after processing our input
            predictedPaddleY = input.paddleY;
        }
    }
    
    // Ensure predicted paddle stays within bounds after reconciliation
    predictedPaddleY = Math.max(0, Math.min(CANVAS_HEIGHT - PADDLE_HEIGHT, predictedPaddleY));
    
    // Update game state to reflect reconciled position
    gameState.localPaddle.y = predictedPaddleY;
}

function sendLifeUpdate() {
    // Send life updates sporadically (only when score changes, not on timer)
    const currentTime = SpixiTools.getTimestamp();
    lastDataSent = currentTime;
    SpixiAppSdk.sendNetworkData(JSON.stringify({
        a: "lives",
        local: gameState.localPaddle.lives,
        remote: gameState.remotePaddle.lives
    }));
}

function sendEndGame() {
    const currentTime = SpixiTools.getTimestamp();
    lastDataSent = currentTime;
    SpixiAppSdk.sendNetworkData(JSON.stringify({
        a: "end",
        local: gameState.localPaddle.lives,
        remote: gameState.remotePaddle.lives
    }));
}

function saveGameState() {
    // Save final game state for statistics/history (optional)
    if (remotePlayerAddress !== '') {
        setTimeout(() => {
            SpixiAppSdk.setStorageData(remotePlayerAddress, btoa(JSON.stringify(gameState)));
        }, 50);
    }
}

// Spixi SDK callbacks
SpixiAppSdk.onInit = function(sid, userAddresses) {
    sessionId = sid;
    const addresses = userAddresses.split(",");
    remotePlayerAddress = addresses[0];
    
    // Local player is always on the right side
    
    // Initialize game UI and start connection
    initGame();
    establishConnection();
    
    // Show waiting screen - always start with fresh game
    const waitingScreen = document.getElementById('waiting-screen');
    const gameScreen = document.getElementById('game-screen');
    waitingScreen.style.display = 'flex';
    gameScreen.style.display = 'none';
    
    const waitingText = document.querySelector('.waiting-text');
    if (waitingText) {
        waitingText.textContent = 'Connecting to opponent...';
    }
};

SpixiAppSdk.onNetworkData = function(senderAddress, data) {
    playerLastSeen = SpixiTools.getTimestamp();
    
    // Track packet rate for connection quality
    packetReceiveCount++;
    const now = Date.now();
    if (now - lastPacketRateCheck >= 1000) {
        currentPacketRate = packetReceiveCount;
        packetReceiveCount = 0;
        lastPacketRateCheck = now;
        
        // Update connection quality
        if (currentPacketRate >= 60) {
            connectionQuality = 'good';
        } else if (currentPacketRate >= 30) {
            connectionQuality = 'fair';
        } else {
            connectionQuality = 'poor';
        }
    }
    
    try {
        const msg = JSON.parse(data);
        
        switch(msg.a) {
            case "connect":
                // Received connection request, reply back with our random number
                if (msg.rand !== undefined) {
                    remoteRandomNumber = msg.rand;
                }
                if (!connectionEstablished) {
                    SpixiAppSdk.sendNetworkData(JSON.stringify({ a: "connect", sid: sessionId, rand: myRandomNumber }));
                    lastDataSent = SpixiTools.getTimestamp();
                    
                    // Only establish connection if we have both random numbers
                    if (remoteRandomNumber !== null) {
                        handleConnectionEstablished();
                    }
                }
                break;
                
            case "ping":
                // Connection keepalive
                break;
                
            case "launch":
                // Ball owner has launched - hide shoot button and update status
                if (!gameState.isBallOwner) {
                    document.getElementById('shootBtn').style.display = 'none';
                    document.getElementById('status-text').textContent = 'Game On!';
                }
                break;
                
            case "state": // Unified game state update
                // Handle sequence acknowledgment for input tracking
                if (msg.lastAck !== undefined) {
                    // Remote player has acknowledged inputs up to msg.lastAck
                    lastAcknowledgedSequence = msg.lastAck;
                    
                    // Remove acknowledged inputs from pending buffer
                    pendingInputs = pendingInputs.filter(input => input.seq > msg.lastAck);
                }
                
                // Perform server reconciliation: sync our predicted state with remote's authoritative view
                // When remote sends paddle position + last ack sequence, we replay our pending inputs
                if (msg.p !== undefined && msg.lastAck !== undefined) {
                    reconcilePaddleState(msg.p, msg.lastAck);
                }
                
                // Update remote paddle target for smooth interpolation
                if (msg.p !== undefined) {
                    remotePaddleTarget = msg.p;
                }
                
                // Readjust ball when receiving data (both players can send now)
                if (msg.b) {
                    // Convert from sender's coordinate system to ours (mirror X)
                    const mirroredX = CANVAS_WIDTH - msg.b.x;
                    const mirroredVx = -msg.b.vx;
                    
                    const velocityChanged = 
                        Math.abs(gameState.ball.vx - mirroredVx) > 0.5 || 
                        Math.abs(gameState.ball.vy - msg.b.vy) > 0.5;
                    
                    if (velocityChanged) {
                        // Bounce detected - resync position and velocity
                        gameState.ball.x = mirroredX;
                        gameState.ball.y = msg.b.y;
                        gameState.ball.vx = mirroredVx;
                        gameState.ball.vy = msg.b.vy;
                    } else {
                        // No bounce - just check for drift
                        const distance = Math.sqrt(
                            Math.pow(gameState.ball.x - mirroredX, 2) + 
                            Math.pow(gameState.ball.y - msg.b.y, 2)
                        );
                        
                        // Only correct if significantly off (late data)
                        if (distance > 100) {
                            gameState.ball.x = mirroredX;
                            gameState.ball.y = msg.b.y;
                        }
                    }
                    
                    // Record ball state for dead reckoning
                    // This allows us to predict ball position between network updates
                    ballLastKnownPosition = {
                        x: gameState.ball.x,
                        y: gameState.ball.y,
                        vx: gameState.ball.vx,
                        vy: gameState.ball.vy,
                        timestamp: Date.now()
                    };
                    
                    // Setup ball interpolation: record current position as start of interpolation
                    ballInterpolationLastPosition = {
                        x: gameState.ball.x,
                        y: gameState.ball.y
                    };
                    ballInterpolationLastUpdateTime = Date.now();
                    
                    // Set interpolation target to the new position
                    ballTarget = {
                        x: mirroredX,
                        y: msg.b.y,
                        vx: mirroredVx,
                        vy: msg.b.vy
                    };
                    
                    // Enable dead reckoning if ball is moving
                    ballDeadReckoningActive = Math.abs(gameState.ball.vx) > 0.1 || Math.abs(gameState.ball.vy) > 0.1;
                }
                break;
                
            case "lives":
                // Update lives from ball owner
                if (!gameState.isBallOwner) {
                    gameState.localPaddle.lives = msg.remote;
                    gameState.remotePaddle.lives = msg.local;
                    updateLivesDisplay();
                }
                break;
                
            case "end":
                // Game ended
                if (!gameState.gameEnded) {
                    gameState.localPaddle.lives = msg.remote;
                    gameState.remotePaddle.lives = msg.local;
                    endGame(gameState.localPaddle.lives > 0);
                }
                break;
                
            case "restart":
                // Restart request
                if (gameState.gameEnded) {
                    restartGame();
                }
                break;
        }
    } catch (e) {
        console.error("Error parsing network data:", e);
    }
};

SpixiAppSdk.onStorageData = function(key, value) {
    // Storage is only used to save final game state
    // Don't restore old game state on startup - always start fresh
    if (value !== 'null') {
        try {
            const savedState = JSON.parse(atob(value));
            // Ignore saved state - we always want to start a new game
            console.log("Previous game state found but ignored - starting fresh");
        } catch (e) {
            console.error("Error parsing saved state:", e);
        }
    }
};

// Start the app on load
window.onload = SpixiAppSdk.fireOnLoad;
